const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";

import { motion } from "framer-motion";
import { Database, Loader2, RefreshCw, TrendingUp, Activity, Gauge } from "lucide-react";

const HOURS_PER_MONTH = 730;

const typeMeta = {
  PostgreSQL: { color: "text-cyan-300", dot: "bg-cyan-400", ring: "border-cyan-400/30 bg-cyan-400/10" },
  Redis: { color: "text-rose-300", dot: "bg-rose-400", ring: "border-rose-400/30 bg-rose-400/10" },
  S3: { color: "text-amber-300", dot: "bg-amber-400", ring: "border-amber-400/30 bg-amber-400/10" },
};

const statusMeta = {
  Ready: { label: "Ready", cls: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10" },
  Provisioning: { label: "Provisioning", cls: "text-amber-300 border-amber-400/30 bg-amber-400/10", pulse: true },
  Expiring: { label: "Expiring", cls: "text-orange-300 border-orange-400/30 bg-orange-400/10" },
  Deleted: { label: "Deleted", cls: "text-zinc-500 border-white/10 bg-white/5" },
};

function liveSpend(res, now) {
  const ms = now - new Date(res.created_date).getTime();
  if (ms < 0 || !res.monthly_cost) return 0;
  return (res.monthly_cost / (HOURS_PER_MONTH * 3600 * 1000)) * ms;
}

const fmt = (n, d = 2) => `$${n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d })}`;

export default function DashboardSection() {
  const [resources, setResources] = useState(null);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    let active = true;
    db.entities.InfrastructureResource.list("-created_date", 50)
      .then((data) => active && setResources(data))
      .catch(() => active && setResources([]));
    const unsub = db.entities.InfrastructureResource.subscribe((event) => {
      setResources((prev) => {
        if (!prev) return prev;
        if (event.type === "create") return [event.data, ...prev];
        if (event.type === "update") return prev.map((r) => (r.id === event.data.id ? event.data : r));
        if (event.type === "delete") return prev.filter((r) => r.id !== event.id);
        return prev;
      });
    });
    return () => {
      active = false;
      unsub && unsub();
    };
  }, []);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const active = (resources || []).filter((r) => r.status !== "Deleted");
  const monthlyTotal = active.reduce((s, r) => s + (Number(r.monthly_cost) || 0), 0);
  const liveTotal = active.reduce((s, r) => s + liveSpend(r, now), 0);

  return (
    <section id="dashboard" className="relative py-24 sm:py-32 border-t border-white/5">
      <div className="pointer-events-none absolute top-1/3 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full bg-cyan-500/[0.06] blur-[140px]" />
      <div className="relative mx-auto max-w-7xl px-6">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div className="max-w-2xl">
            <span className="text-xs font-medium uppercase tracking-[0.2em] text-cyan-300/80">
              Live dashboard
            </span>
            <h2 className="mt-3 text-3xl sm:text-5xl font-semibold tracking-[-0.02em]">
              Your resources, in real time
            </h2>
            <p className="mt-4 text-zinc-400 leading-relaxed">
              Every active resource and its estimated monthly cost — with live spend
              ticking up by the second as your infrastructure runs.
            </p>
          </div>
          <span className="inline-flex items-center gap-2 self-start rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1.5 text-xs text-emerald-300">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Live
          </span>
        </div>

        {/* summary stats */}
        <div className="mt-10 grid sm:grid-cols-3 gap-4">
          <StatCard icon={Gauge} label="Estimated monthly cost" value={fmt(monthlyTotal)} accent="from-cyan-400 to-emerald-400" />
          <StatCard icon={Activity} label="Active resources" value={String(active.length)} accent="from-violet-400 to-cyan-400" />
          <StatCard icon={TrendingUp} label="Live spend so far" value={fmt(liveTotal, 4)} accent="from-amber-300 to-emerald-300" live />
        </div>

        {/* resource list */}
        <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.025] overflow-hidden">
          <div className="hidden sm:grid grid-cols-12 gap-4 px-5 py-3 border-b border-white/10 text-[11px] uppercase tracking-wider text-zinc-500">
            <div className="col-span-4">Resource</div>
            <div className="col-span-2">Type</div>
            <div className="col-span-2">Status</div>
            <div className="col-span-2 text-right">Monthly</div>
            <div className="col-span-2 text-right">Live spend</div>
          </div>

          {resources === null ? (
            <div className="flex items-center justify-center gap-2 py-16 text-sm text-zinc-500">
              <Loader2 className="w-4 h-4 animate-spin" /> Loading resources…
            </div>
          ) : active.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
              <RefreshCw className="w-6 h-6 text-zinc-600" />
              <p className="text-sm text-zinc-500">No active resources yet. Provision one to see it here.</p>
            </div>
          ) : (
            <div className="divide-y divide-white/5">
              {active.map((r) => {
                const t = typeMeta[r.resource_type] || typeMeta.PostgreSQL;
                const s = statusMeta[r.status] || statusMeta.Ready;
                return (
                  <div key={r.id} className="grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-4 px-5 py-4 items-center hover:bg-white/[0.02] transition-colors">
                    <div className="sm:col-span-4 flex items-center gap-3 min-w-0">
                      <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg border ${t.ring} ${t.color}`}>
                        <Database className="w-4 h-4" />
                      </span>
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{r.name}</div>
                        <div className="text-[11px] text-zinc-500">{r.size} · {r.region}</div>
                      </div>
                    </div>
                    <div className="sm:col-span-2 flex items-center gap-2 text-sm text-zinc-300">
                      <span className={`h-1.5 w-1.5 rounded-full ${t.dot}`} /> {r.resource_type}
                    </div>
                    <div className="sm:col-span-2">
                      <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] ${s.cls}`}>
                        {s.pulse && <span className="h-1.5 w-1.5 rounded-full bg-current animate-pulse" />}
                        {s.label}
                      </span>
                    </div>
                    <div className="sm:col-span-2 sm:text-right text-sm font-medium text-emerald-300">{fmt(Number(r.monthly_cost) || 0)}</div>
                    <div className="sm:col-span-2 sm:text-right font-mono text-[13px] text-cyan-200 tabular-nums">{fmt(liveSpend(r, now), 4)}</div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function StatCard({ icon: Icon, label, value, accent, live }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.45 }}
      className="relative rounded-2xl border border-white/10 bg-white/[0.025] p-5 overflow-hidden"
    >
      <div className="flex items-center justify-between">
        <span className={`grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br ${accent} text-black`}>
          <Icon className="w-4 h-4" />
        </span>
        {live && <span className="text-[10px] text-emerald-400">● live</span>}
      </div>
      <div className="mt-4 text-2xl font-semibold tabular-nums">{value}</div>
      <div className="mt-1 text-xs text-zinc-500">{label}</div>
    </motion.div>
  );
}