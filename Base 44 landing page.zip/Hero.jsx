import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Github } from "lucide-react";
import HeroPreview from "@/components/landing/HeroPreview";

const REPO_URL = "https://github.com/amco-f22/infractrl";

export default function Hero() {
  return (
    <section className="relative pt-36 sm:pt-44 pb-16">
      {/* ambient glows */}
      <div className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full bg-cyan-500/15 blur-[150px]" />
      <div className="pointer-events-none absolute top-10 right-0 w-[400px] h-[400px] rounded-full bg-emerald-500/10 blur-[120px]" />
      <div className="pointer-events-none absolute top-32 left-0 w-[380px] h-[380px] rounded-full bg-violet-600/10 blur-[120px]" />

      <div className="relative mx-auto max-w-7xl px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <a
            href={REPO_URL}
            target="_blank"
            rel="noreferrer"
            className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs text-zinc-300 backdrop-blur hover:border-white/20 transition-colors"
          >
            <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px] shadow-emerald-400" />
            Now provisioning PostgreSQL, Redis &amp; S3
            <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
          </a>

          <h1 className="mx-auto mt-7 max-w-4xl text-[2.75rem] leading-[1.02] sm:text-6xl lg:text-7xl font-semibold tracking-[-0.03em]">
            Request cloud databases
            <br className="hidden sm:block" /> in{" "}
            <span className="relative whitespace-nowrap">
              <span className="bg-gradient-to-r from-cyan-300 via-emerald-300 to-teal-200 bg-clip-text text-transparent">
                5 minutes
              </span>
              <svg className="absolute -bottom-2 left-0 w-full" height="10" viewBox="0 0 300 10" preserveAspectRatio="none">
                <path d="M2 7 Q 150 -2 298 6" fill="none" stroke="url(#g)" strokeWidth="2.5" strokeLinecap="round" opacity="0.7" />
                <defs>
                  <linearGradient id="g" x1="0" x2="1">
                    <stop offset="0" stopColor="#22d3ee" />
                    <stop offset="1" stopColor="#34d399" />
                  </linearGradient>
                </defs>
              </svg>
            </span>
            , not 5 days
          </h1>

          <p className="mx-auto mt-7 max-w-2xl text-lg text-zinc-400 leading-relaxed">
            InfraCtrl kills the DevOps bottleneck. Self-serve dev and staging
            environments with automated Terraform provisioning, real-time cost
            tracking, and instant connection strings — then forget about cleanup.
          </p>

          <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/register"
              className="group inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-black hover:bg-zinc-200 transition-colors"
            >
              Get started free
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
            <a
              href={REPO_URL}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/[0.03] px-6 py-3 text-sm font-medium text-white hover:bg-white/[0.08] transition-colors"
            >
              <Github className="w-4 h-4" />
              Star on GitHub
            </a>
          </div>
        </motion.div>

        <HeroPreview />
      </div>
    </section>
  );
}