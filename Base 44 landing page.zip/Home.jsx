import LandingNav from "@/components/landing/LandingNav";
import Hero from "@/components/landing/Hero";
import Features from "@/components/landing/Features";
import DashboardSection from "@/components/landing/DashboardSection";
import HowItWorks from "@/components/landing/HowItWorks";
import TechStack from "@/components/landing/TechStack";
import CTASection from "@/components/landing/CTASection";
import LandingFooter from "@/components/landing/LandingFooter";

export default function Home() {
  return (
    <div className="relative min-h-screen bg-black text-white antialiased overflow-x-hidden font-body selection:bg-cyan-400/30">
      {/* fixed grid-texture backdrop with radial vignette mask */}
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_75%_60%_at_50%_0%,#000_40%,transparent_100%)]" />
      <LandingNav />
      <main>
        <Hero />
        <Features />
        <DashboardSection />
        <HowItWorks />
        <TechStack />
        <CTASection />
      </main>
      <LandingFooter />
    </div>
  );
}