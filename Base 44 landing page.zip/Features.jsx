import { motion } from "framer-motion";
import {
  ProvisioningCell,
  FormCell,
  CostCell,
  SlackCell,
  SyncCell,
  CleanupCell,
} from "@/components/landing/BentoCells";

export default function Features() {
  return (
    <section id="features" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-2xl">
          <span className="text-xs font-medium uppercase tracking-[0.2em] text-cyan-300/80">
            Features
          </span>
          <h2 className="mt-3 text-3xl sm:text-5xl font-semibold tracking-[-0.02em]">
            Everything between request and connection
          </h2>
          <p className="mt-4 text-zinc-400 leading-relaxed">
            InfraCtrl closes the loop on infrastructure self-service — from the
            first click to automatic teardown.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="mt-14 grid grid-cols-1 lg:grid-cols-4 lg:auto-rows-[minmax(0,1fr)] gap-4"
        >
          <ProvisioningCell />
          <FormCell />
          <CostCell />
          <SlackCell />
          <SyncCell />
          <CleanupCell />
        </motion.div>
      </div>
    </section>
  );
}