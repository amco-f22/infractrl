import { motion } from "framer-motion";

const stack = [
  { name: "Next.js", role: "Frontend", note: "App Router · Tailwind" },
  { name: "FastAPI", role: "Backend", note: "Python · async" },
  { name: "PostgreSQL", role: "Database", note: "via Supabase" },
  { name: "Terraform", role: "Infrastructure", note: "AWS IaC" },
  { name: "GitHub Actions", role: "CI/CD", note: "OIDC keyless auth" },
  { name: "Vercel + Railway", role: "Deployment", note: "zero-config" },
];

const marquee = ["PostgreSQL", "Redis", "Amazon S3", "AWS RDS", "Terraform", "GitHub Actions", "Slack", "Supabase"];

export default function TechStack() {
  return (
    <section id="stack" className="relative py-24 sm:py-32 border-t border-white/5">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-2xl">
          <span className="text-xs font-medium uppercase tracking-[0.2em] text-violet-300/80">
            Tech stack
          </span>
          <h2 className="mt-3 text-3xl sm:text-5xl font-semibold tracking-[-0.02em]">
            Built on a stack you already trust
          </h2>
          <p className="mt-4 text-zinc-400 leading-relaxed">
            Production-grade tools, wired together for reliable, repeatable
            deployments — and a $0/month footprint within free tiers.
          </p>
        </div>

        {/* marquee */}
        <div className="relative mt-12 overflow-hidden [mask-image:linear-gradient(to_right,transparent,#000_12%,#000_88%,transparent)]">
          <motion.div
            className="flex gap-3 w-max"
            animate={{ x: ["0%", "-50%"] }}
            transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
          >
            {[...marquee, ...marquee].map((m, i) => (
              <span
                key={i}
                className="shrink-0 rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-sm text-zinc-300"
              >
                {m}
              </span>
            ))}
          </motion.div>
        </div>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {stack.map((s, i) => (
            <motion.div
              key={s.name}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.45, delay: (i % 3) * 0.06 }}
              className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.025] p-5 hover:border-white/20 transition-colors"
            >
              <span className="grid place-items-center w-12 h-12 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/10 text-cyan-300 font-semibold">
                {s.name.charAt(0)}
              </span>
              <div>
                <div className="font-medium">{s.name}</div>
                <div className="text-xs text-zinc-500">{s.role} · {s.note}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}