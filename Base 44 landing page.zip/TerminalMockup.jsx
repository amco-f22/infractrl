import { motion } from "framer-motion";

const lines = [
  { t: "$ infractl provision prod-postgres-01", c: "text-zinc-200" },
  { t: "→ triggering github actions …", c: "text-zinc-500" },
  { t: "✓ terraform init", c: "text-emerald-400" },
  { t: "✓ terraform apply — rds postgres 16", c: "text-emerald-400" },
  { t: "  aws_db_instance.postgres: Creating…", c: "text-zinc-500" },
  { t: "  aws_db_instance.postgres: Creation complete [id=prod-pg-01]", c: "text-cyan-300" },
  { t: "✓ state synced to dashboard", c: "text-emerald-400" },
  { t: "✓ connection string posted to #alerts", c: "text-emerald-400" },
  { t: "done in 4m 12s · est. $14.20/mo", c: "text-zinc-300" },
];

export function TerminalMockup() {
  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/5">
        <span className="h-2.5 w-2.5 rounded-full bg-red-500/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-emerald-500/80" />
        <span className="ml-2 text-[11px] text-zinc-500 font-mono">infractl — zsh</span>
      </div>
      <div className="font-mono text-[12.5px] leading-relaxed p-4 space-y-1.5">
        {lines.map((l, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 + i * 0.28, duration: 0.3 }}
            className={l.c}
          >
            {l.t}
          </motion.div>
        ))}
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 0] }}
          transition={{ delay: 0.4 + lines.length * 0.28, repeat: Infinity, duration: 1 }}
          className="inline-block h-3.5 w-2 bg-cyan-300 translate-y-0.5"
        />
      </div>
    </div>
  );
}