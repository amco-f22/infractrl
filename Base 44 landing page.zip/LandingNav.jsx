import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Github, Menu, X } from "lucide-react";

const REPO_URL = "https://github.com/amco-f22/infractrl";

const links = [
  { label: "Features", href: "#features" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Stack", href: "#stack" },
];

export default function LandingNav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? "border-b border-white/10 bg-[#000000]/80 backdrop-blur-xl"
          : "border-b border-transparent"
      }`}
    >
      <nav className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group">
          <span className="grid place-items-center w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-emerald-400 text-[#000000] font-bold shadow-lg shadow-emerald-500/20">
            iC
          </span>
          <span className="font-semibold tracking-tight text-[17px]">
            Infra<span className="text-cyan-300">Ctrl</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm text-zinc-400 hover:text-white transition-colors"
            >
              {l.label}
            </a>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          <a
            href={REPO_URL}
            target="_blank"
            rel="noreferrer"
            className="grid place-items-center w-9 h-9 rounded-lg border border-white/10 text-zinc-300 hover:text-white hover:border-white/20 transition-colors"
            aria-label="GitHub repository"
          >
            <Github className="w-4 h-4" />
          </a>
          <Link
            to="/register"
            className="text-sm font-medium px-4 py-2 rounded-lg bg-white text-[#000000] hover:bg-zinc-200 transition-colors"
          >
            Get started
          </Link>
        </div>

        <button
          className="md:hidden grid place-items-center w-9 h-9 rounded-lg border border-white/10"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden border-t border-white/10 bg-[#000000]/95 backdrop-blur-xl px-6 py-4 space-y-3">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block text-sm text-zinc-300 hover:text-white"
            >
              {l.label}
            </a>
          ))}
          <Link
            to="/register"
            onClick={() => setOpen(false)}
            className="block text-center text-sm font-medium px-4 py-2 rounded-lg bg-white text-[#000000]"
          >
            Get started
          </Link>
        </div>
      )}
    </header>
  );
}