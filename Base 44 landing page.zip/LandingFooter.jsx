import { Link } from "react-router-dom";
import { Github, Linkedin } from "lucide-react";

const REPO_URL = "https://github.com/amco-f22/infractrl";
const LINKEDIN_URL = "https://linkedin.com/in/amco-f22";

export default function LandingFooter() {
  return (
    <footer className="relative border-t border-white/10 bg-black">
      <div className="mx-auto max-w-7xl px-6 py-14 grid md:grid-cols-3 gap-8">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="grid place-items-center w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-emerald-400 text-black font-bold">
              iC
            </span>
            <span className="font-semibold tracking-tight text-[17px]">
              Infra<span className="text-cyan-300">Ctrl</span>
            </span>
          </div>
          <p className="mt-4 text-sm text-zinc-500 max-w-xs leading-relaxed">
            Simple self-service infrastructure. Request cloud databases in minutes,
            not days.
          </p>
        </div>

        <div className="text-sm">
          <div className="text-zinc-400 font-medium">Product</div>
          <ul className="mt-3 space-y-2 text-zinc-500">
            <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
            <li><a href="#how-it-works" className="hover:text-white transition-colors">How it works</a></li>
            <li><a href="#stack" className="hover:text-white transition-colors">Tech stack</a></li>
            <li><Link to="/register" className="hover:text-white transition-colors">Get started</Link></li>
          </ul>
        </div>

        <div className="text-sm">
          <div className="text-zinc-400 font-medium">Built by</div>
          <p className="mt-3 text-zinc-300 font-medium">Aman Kumar</p>
          <p className="text-zinc-500 text-xs">Final year B.Tech, DIT University</p>
          <div className="mt-4 flex items-center gap-3">
            <a
              href={REPO_URL}
              target="_blank"
              rel="noreferrer"
              className="grid place-items-center w-9 h-9 rounded-lg border border-white/10 text-zinc-300 hover:text-white hover:border-white/20 transition-colors"
              aria-label="GitHub"
            >
              <Github className="w-4 h-4" />
            </a>
            <a
              href={LINKEDIN_URL}
              target="_blank"
              rel="noreferrer"
              className="grid place-items-center w-9 h-9 rounded-lg border border-white/10 text-zinc-300 hover:text-white hover:border-white/20 transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-zinc-500">
          <span>© {new Date().getFullYear()} InfraCtrl. MIT License.</span>
          <span className="font-mono">made with terraform · actions · too little sleep</span>
        </div>
      </div>
    </footer>
  );
}