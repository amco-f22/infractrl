const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { TerminalMockup } from "@/components/landing/TerminalMockup";
import { Database, Sliders, CircleDollarSign, Bell, Link2, Recycle } from "lucide-react";

const wrap =
  "relative rounded-2xl border border-white/10 bg-white/[0.025] p-5 overflow-hidden hover:border-white/20 transition-colors";

export function ProvisioningCell() {
  return (
    <div className={`${wrap} lg:col-span-2 lg:row-span-2 flex flex-col`}>
      <div className="pointer-events-none absolute -top-16 -right-10 h-40 w-40 rounded-full bg-emerald-500/15 blur-3xl" />
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-cyan-400 to-emerald-400 text-black">
          <Database className="w-4 h-4" />
        </span>
        <h3 className="text-base font-medium">Automated CI/CD provisioning</h3>
      </div>
      <p className="mt-2 text-sm text-zinc-400 max-w-sm">
        Submit a request and GitHub Actions runs <span className="font-mono text-cyan-300">terraform apply</span> in AWS — keyless OIDC, no shared credentials.
      </p>
      <div className="mt-4 flex-1 rounded-xl border border-white/10 bg-[#0a0a0c] min-h-[220px]">
        <TerminalMockup />
      </div>
    </div>
  );
}

export function FormCell() {
  return (
    <div className={`${wrap} lg:col-span-2`}>
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-cyan-300">
          <Sliders className="w-4 h-4" />
        </span>
        <h3 className="text-base font-medium">Self-service form</h3>
      </div>
      <p className="mt-2 text-sm text-zinc-400">Pick a resource, environment, and size — in seconds.</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {["PostgreSQL", "Redis", "S3"].map((r, i) => (
          <span
            key={r}
            className={`rounded-lg border px-3 py-1.5 text-xs ${
              i === 0 ? "border-cyan-400/40 bg-cyan-400/10 text-cyan-200" : "border-white/10 bg-white/[0.03] text-zinc-400"
            }`}
          >
            {r}
          </span>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-3 rounded-lg border border-white/10 bg-white/[0.03] p-2.5">
        <span className="text-xs text-zinc-500">Size</span>
        <div className="flex flex-1 gap-1.5">
          {["Small", "Medium", "Large"].map((s, i) => (
            <div key={s} className="flex-1 rounded-md px-2 py-1.5 text-center text-[11px] text-zinc-400 bg-white/[0.02] border border-white/5">
              {s}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function CostCell() {
  return (
    <div className={`${wrap}`}>
      <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-emerald-300">
        <CircleDollarSign className="w-4 h-4" />
      </span>
      <h3 className="mt-3 text-base font-medium">Cost tracking</h3>
      <div className="mt-3 flex items-end gap-1.5 h-16">
        {[40, 65, 35, 80, 55, 70].map((h, i) => (
          <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-emerald-500/30 to-emerald-400" style={{ height: `${h}%` }} />
        ))}
      </div>
      <div className="mt-2 flex items-center justify-between text-xs">
        <span className="text-zinc-500">Est. run rate</span>
        <span className="font-semibold text-emerald-300">$14.20/mo</span>
      </div>
    </div>
  );
}

export function SlackCell() {
  return (
    <div className={`${wrap}`}>
      <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-fuchsia-300">
        <Bell className="w-4 h-4" />
      </span>
      <h3 className="mt-3 text-base font-medium">Slack alerts</h3>
      <div className="mt-3 rounded-lg border border-white/10 bg-white/[0.03] p-2.5">
        <div className="flex items-center gap-2">
          <span className="grid h-5 w-5 place-items-center rounded bg-fuchsia-500/80 text-[10px] font-bold text-black">iC</span>
          <span className="text-[11px] font-medium">InfraCtrl</span>
          <span className="text-[10px] text-zinc-500">just now</span>
        </div>
        <p className="mt-1.5 text-[11px] text-zinc-400">✅ prod-postgres-01 is ready. Expires in 7 days.</p>
      </div>
    </div>
  );
}

export function SyncCell() {
  return (
    <div className={`${wrap} lg:col-span-2`}>
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-cyan-300">
          <Link2 className="w-4 h-4" />
        </span>
        <h3 className="text-base font-medium">Instant access &amp; sync</h3>
      </div>
      <p className="mt-2 text-sm text-zinc-400">Connection strings sync from Terraform output straight to your dashboard.</p>
      <div className="mt-3 rounded-lg border border-white/10 bg-[#0a0a0c] p-3 font-mono text-[11px] text-zinc-300 overflow-x-auto">
        <span className="text-zinc-500">$</span> infractl connection prod-postgres-01
        <br />
        <span className="text-emerald-400">postgresql://infraadmin:••••••@db.infractl.io:5432/infractl</span>
      </div>
    </div>
  );
}

export function CleanupCell() {
  return (
    <div className={`${wrap} lg:col-span-2`}>
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-teal-300">
          <Recycle className="w-4 h-4" />
        </span>
        <h3 className="text-base font-medium">Auto-cleanup</h3>
      </div>
      <p className="mt-2 text-sm text-zinc-400 max-w-md">Expired resources are destroyed with <span className="font-mono text-teal-300">terraform destroy</span> — no orphaned instances, no surprise bills.</p>
      <div className="mt-3 flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.03] p-3">
        <div className="flex items-center gap-3">
          <div className="font-mono text-2xl font-semibold tabular-nums">6d 23h</div>
          <span className="text-[11px] text-zinc-500">until auto-destroy<br />Slack warns 24h prior</span>
        </div>
        <span className="rounded-md border border-teal-400/30 bg-teal-400/10 px-2.5 py-1 text-[11px] text-teal-200">scheduled</span>
      </div>
    </div>
  );
}